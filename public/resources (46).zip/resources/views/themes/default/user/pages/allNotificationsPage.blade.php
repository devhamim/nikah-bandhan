@php
/*
---------------------------------------------------
ALl Notifications Page
Displays all the notification of an user of the
website.
---------------------------------------------------
*/
@endphp
@extends('user.layouts.secondaryLayout')

@section('title')
All Notifications
@endsection

@section('sitebody')
<div class="all-notifs-container static-container">
    <div class="all-notifs static">
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>
        <div class="notif-card">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus blanditiis perferendis maiores sit ipsa
            iste optio! Voluptate ducimus soluta officia. Laborum facilis officia autem quam?
        </div>

    </div>
</div>
@endsection
