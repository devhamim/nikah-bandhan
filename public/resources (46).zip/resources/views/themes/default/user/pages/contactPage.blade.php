@php
/*
---------------------------------------------------
Contact Page
Displays the contact information of the website
---------------------------------------------------
*/
@endphp

@extends('user.layouts.secondaryLayout')

@section('title')
Contact Us
@endsection

@section('sitebody')
<div class="static-container">
    <div class="static">
        <h4>Contact Us</h4>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio est illum consectetur placeat fuga quae, a
            laboriosam sed quo ullam aperiam dolorem magnam, ea nisi totam soluta accusamus quis. Tempore laboriosam
            sint voluptatem et commodi adipisci eius ex nam nostrum reiciendis. Architecto at incidunt quae velit a
            provident deserunt, accusamus nulla odit aperiam dolorum iusto ex, eum mollitia corrupti id, ab possimus
            quis! Autem architecto numquam nesciunt possimus, obcaecati ea saepe quasi soluta cum aspernatur sit
            voluptates. Facere numquam, quidem soluta sunt asperiores repellendus, beatae facilis labore, exercitationem
            suscipit aspernatur impedit deserunt pariatur illum reiciendis incidunt possimus. Quod necessitatibus
            consequuntur beatae eum, aliquam voluptatem impedit deserunt laboriosam perferendis reiciendis provident
            autem sed esse ipsum ad suscipit! Molestiae reiciendis amet vitae, soluta, perspiciatis numquam minus quos,
            velit animi quae deleniti? Odit, reiciendis? Veniam, recusandae eveniet voluptates ut commodi hic itaque
            nemo, minima, eos quibusdam ipsum. Non molestias inventore vel odit consequatur!</p>
    </div>
</div>
@endsection
