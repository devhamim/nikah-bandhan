@extends('user.layouts.secondaryLayout')

@section('sitebody')
<div class="guidelines-container">
    <div class="guidelines">
        <h3 class="guidelines-heading"><i class="bi bi-info-circle"></i> Guidelines</h3>
        <ul>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi nesciunt quasi fugiat quibusdam
                consectetur ullam asperiores, ipsa rerum natus impedit ab repellendus quo a dolorum, inventore
                consequuntur atque odio obcaecati. Natus commodi rem dolorum eius labore! Blanditiis quidem fugit ullam,
                fugiat ipsa, expedita qui, perspiciatis dolores nobis voluptatum quam minima!</li>
        </ul>
    </div>
</div>
@endsection
