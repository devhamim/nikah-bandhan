1.masterLayout just defines html5 document and links stylesheet, loads scripts, stacks pushes and eventually loads another layout.

2.Any other layouts should extend it.
