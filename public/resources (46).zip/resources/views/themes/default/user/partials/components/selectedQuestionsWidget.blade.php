@php
/*
--------------------------------------------------------------------------
| Selected questions widget
|---------------------------------------------------------------------------
| Responsibility: Displaying selection of questions crafted for the user
| via algorithm.
*/
@endphp
<div class="left-widget branding-border" style="">
    <div class="p-2 sidebar-widget b-c-b"
        style="border-bottom:1px solid lightgray;color:white;background-image:url({{asset('images/quest-gift.png')}});background-repeat:no-repeat;background-position:right;">
        <i class="far fa-question-circle"></i> Questions for you
    </div>
    <div class="p-2">
        <ul id="selected_quests">
            <li>১.আমার ফোনের চার্জ অনেক দ্রুত শেষ হয়ে যায়। এর সমাধান কী?</li>
            <li>১.আমার ফোনের চার্জ অনেক দ্রুত শেষ হয়ে যায়। এর সমাধান কী?</li>
            <li>১.আমার ফোনের চার্জ অনেক দ্রুত শেষ হয়ে যায়। এর সমাধান কী?</li>
            <li>১.আমার ফোনের চার্জ অনেক দ্রুত শেষ হয়ে যায়। এর সমাধান কী?</li>
            <li>১.আমার ফোনের চার্জ অনেক দ্রুত শেষ হয়ে যায়। এর সমাধান কী?</li>
        </ul>
    </div>
</div>