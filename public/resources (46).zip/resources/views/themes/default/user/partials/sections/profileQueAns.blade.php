<section class="container profile-qa">
    <div class="row">
        <div class="col-md-6">
            <div>
                <h5>your quesitons</h5>
                <ul>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <a href="#">see all</a>
                </ul>
            </div>
        </div>

        <div class="col-md-6">
            <div>
                <h5>Answers in</h5>
                <ul>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <a href="#">see all</a>
                </ul>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div>
                <h5>bookmarked questions</h5>
                <ul>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <a href="#">see all</a>
                </ul>
            </div>
        </div>

        <div class="col-md-6">
            <div>
                <h5>followed questions</h5>
                <ul>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, voluptate.</li>
                    <a href="#">see all</a>
                </ul>
            </div>
        </div>
    </div>
</section>
