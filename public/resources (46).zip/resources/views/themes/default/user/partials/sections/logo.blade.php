<div class="row d-flex justify-content-start mt-5 mr-5">
    <div class="featured-box featured-box-primary mt-0">jhgj</div>
</div>
