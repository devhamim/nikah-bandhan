{{--------------------------------------------------------------------------
| Notifications
|---------------------------------------------------------------------------
|
| Responsibility: Displaying all the notifications of the current user.
--------------------------------------------------------------------------}}

@php
/*
--------------------------------------------------------------------------
| Categories widget
|---------------------------------------------------------------------------
| Responsibility: Displaying categories of questions.
*/
@endphp
<div class="dropdown-menu mt-1 p-1" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">Action</a>
    <a class="dropdown-item" href="#">Another action</a>
    <a class="dropdown-item" href="#">Something else here</a>
</div>

@push('styles_inside_head_tag')
<style>

</style>
@endpush