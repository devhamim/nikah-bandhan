
  <div class="main main-raised" style="margin-top: 70px;">
    <div class="profile-content">
        <div class="container" style="min-height: 500px;">
    <div class="row">
        <div class="col-sm-10 mx-auto">
            

@include('user.includes.others.profileHead')

<div class="row">
    <div class="col-sm-3">
        <div class="box box-widget" style="margin-left: 50px;">
            <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-cog"></i> &nbsp; Settings</h3>
            </div>
            <div class="box-body">

                <table class="table table-bordered table-condensed">
                    <tr>
                        <td><a class="btn-link" href="#">Edit My Profile</a></td>
                    </tr>

                    <tr>
                        <td><a class="btn-link" href="#">Edit My Profile</a></td>
                    </tr>
                    
                    <tr>
                        <td><a class="btn-link" href="#">Edit My Profile</a></td>
                    </tr>

                    <tr>
                        <td><a class="btn-link" href="#">Edit My Profile</a></td>
                    </tr>

                    <tr>
                        <td><a class="btn-link" href="#">Edit My Profile</a></td>
                    </tr>

                    <tr>
                        <td><a class="btn-link" href="#">Edit My Profile</a></td>
                    </tr>

                </table>
 
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        
    </div>
</div>
 

</div>
</div>
</div>
        </div>
    </div>
