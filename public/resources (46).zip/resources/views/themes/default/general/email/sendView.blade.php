To Verify Your Email, Please
<a href="{{route('sendEmailDone',['email' => $newuser->email, 'verifyToken' => $newuser->verifyToken])}}"> Click
    Here</a>.