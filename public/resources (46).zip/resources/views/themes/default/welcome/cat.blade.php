@extends('welcome.layouts.welcomeMaster')
{{-- @section('title', 'Dhaka Metro News') --}}

@push('css') 
@endpush

@section('content')
@include('welcome.parts.cat')
@endsection


@push('js')
@endpush
