 

<div class="row">
  <div class="col-sm-12">

 

    <div class="box box-widget">
            <div class="box-header w3-panel w3-leftbar w3-border-green">
              <h3 class="box-title">
                 ফটো গ্যালারি
              </h3>
            </div>
            <div class="box-body w3-bottombar w3-topbar">


              <div class="row">
                <div class="col-sm-7">
                  <ul class="pgwSlideshow">
                <li><img  src="{{asset('img/fi.png')}}" alt="1 San Francisco, USA" data-description="Golden Gate Bridge"></li>
                <li><img src="{{asset('img/logo_bn.jpg')}}" alt="2 Rio de Janeiro, Brazil"></li>
                <li><img src="{{asset('img/fi.png')}}" alt="3 " data-large-src="{{asset('img/fi.png')}}"></li>
                <li><img src="{{asset('img/logo_bn.jpg')}}" alt="4 "></li>
                <li><img src="{{asset('img/fi.png')}}" alt="5 "></li>
                <li><img src="{{asset('img/logo_bn.jpg')}}" alt="6 "></li>
                <li><img src="{{asset('img/fi.png')}}" alt="7 "></li>
                <li><img src="{{asset('img/logo_bn.jpg')}}" alt="8 "></li>
                <li><img src="{{asset('img/fi.png')}}" alt="9 "></li>
                <li><img src="{{asset('img/logo_bn.jpg')}}" alt="10 "></li>
                <li><img src="{{asset('img/fi.png')}}" alt="11 "></li>
                <li>
                    <a href="http://en.wikipedia.org/wiki/Monaco" target="_blank">
                        <img src="{{asset('img/logo_bn.jpg')}}" alt="12 Monaco">
                    </a>
                </li>
            </ul>

                </div>
                <div class="col-sm-5">
                  
                  <div class="row">
                    <div class="col-sm-6">
                      <a href="#"> 
                      <div class="w3-display-container">
                      <img src="{{asset('img/fi.png')}}" alt="Lights" style="width:100%">
                      <div class="w3-padding w3-display-topleft">
                        <button class="btn btn-default"><i class="fa fa-camera-retro fa-2x"></i></button>                        
                      </div>                     
                    </div>
                    <div class="w3-container">
                      <p class="w3-text-gray">Tue, Mar 12, 2018</p>
                    </div>
                  </a>

                      
                    </div>
                    <div class="col-sm-6">
                      <a href="#"> 
                      <div class="w3-display-container">
                      <img src="{{asset('img/fi.png')}}" alt="Lights" style="width:100%">
                      <div class="w3-padding w3-display-topleft">
                        <button class="btn btn-default"><i class="fa fa-camera-retro fa-2x"></i></button>                        
                      </div>                     
                    </div>
                    <div class="w3-container">
                      <p class="w3-text-gray">Tue, Mar 12, 2018</p>
                    </div>
                  </a>
                    </div>
                  </div>


                  <div class="row">
                    <div class="col-sm-6">
                      <a href="#"> 
                      <div class="w3-display-container">
                      <img src="{{asset('img/fi.png')}}" alt="Lights" style="width:100%">
                      <div class="w3-padding w3-display-topleft">
                        <button class="btn btn-default"><i class="fa fa-camera-retro fa-2x"></i></button>                        
                      </div>                     
                    </div>
                    <div class="w3-container">
                      <p class="w3-text-gray">Tue, Mar 12, 2018</p>
                    </div>
                  </a>

                      
                    </div>
                    <div class="col-sm-6">
                      <a href="#"> 
                      <div class="w3-display-container">
                      <img src="{{asset('img/fi.png')}}" alt="Lights" style="width:100%">
                      <div class="w3-padding w3-display-topleft">
                        <button class="btn btn-default"><i class="fa fa-camera-retro fa-2x"></i></button>                        
                      </div>                     
                    </div>
                    <div class="w3-container">
                      <p class="w3-text-gray">Tue, Mar 12, 2018</p>
                    </div>
                  </a>
                    </div>
                  </div>


                  <div class="row">
                    <div class="col-sm-6">
                      <a href="#"> 
                      <div class="w3-display-container">
                      <img src="{{asset('img/fi.png')}}" alt="Lights" style="width:100%">
                      <div class="w3-padding w3-display-topleft">
                        <button class="btn btn-default"><i class="fa fa-camera-retro fa-2x"></i></button>                        
                      </div>                     
                    </div>
                    <div class="w3-container">
                      <p class="w3-text-gray">Tue, Mar 12, 2018</p>
                    </div>
                  </a>

                      
                    </div>
                    <div class="col-sm-6">
                      <a href="#"> 
                      <div class="w3-display-container">
                      <img src="{{asset('img/fi.png')}}" alt="Lights" style="width:100%">
                      <div class="w3-padding w3-display-topleft">
                        <button class="btn btn-default"><i class="fa fa-camera-retro fa-2x"></i></button>                        
                      </div>                     
                    </div>
                    <div class="w3-container">
                      <p class="w3-text-gray">Tue, Mar 12, 2018</p>
                    </div>
                  </a>
                    </div>
                  </div>
                  



                </div>

              </div>

              
               
            </div>
          </div>
              
 
              
            </div>
          </div>
      
 

 