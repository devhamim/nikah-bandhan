@if(isset($frontRight2))
{!! $frontRight2->description !!}
@endif
