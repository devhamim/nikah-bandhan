@if(isset($frontLeft3))
{!! $frontLeft3->description !!}
@endif