@if(isset($frontLeft1))
{!! $frontLeft1->description !!}
@endif

