<div class="row">
  <div class="col-sm-12">
    <div class="box box-widget">
      <div class="box-header">
        <h3 class="box-title">
          <i class="ion-ios-location"></i> Dhaka &nbsp;&nbsp;
        <i class="fa fa-calendar"></i> {{$today->toDayDateTimeString()}} &nbsp;&nbsp; <i class="fa fa-clock-o"></i> Updated: {{$time}}
        </h3>
      </div>
    </div>
  </div>
</div>