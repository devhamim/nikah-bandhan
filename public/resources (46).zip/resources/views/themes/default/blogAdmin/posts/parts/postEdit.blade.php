    <section class="content-header">
      <h1>
        Post
        <small>Update</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-plus"></i> Post</a></li>
        <li class="active">Update</li>
      </ol>
    </section>

     <section class="content">

     @include('blogAdmin.posts.includes.forms.postEdit')


     </section>

