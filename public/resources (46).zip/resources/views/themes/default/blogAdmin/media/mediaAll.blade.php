@extends('blogAdmin.layouts.blogAdminMaster')

@push('css')
@endpush

@section('content')
  @include('blogAdmin.media.parts.mediaAll')
@endsection


@push('js')
@endpush
