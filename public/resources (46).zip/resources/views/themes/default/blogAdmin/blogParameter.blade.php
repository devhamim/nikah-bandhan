@extends('blogAdmin.layouts.blogAdminMaster')

@push('css')
@endpush

@section('content')

  @include('blogAdmin.parts.blogParameter')

@endsection


@push('js')
@endpush
