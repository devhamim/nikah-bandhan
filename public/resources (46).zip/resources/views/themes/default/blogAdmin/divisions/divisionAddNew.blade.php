@extends('admin.master.dashboardmaster')
@section('title', 'Dhaka Metro News')

@push('css')
@endpush

@section('content')
  @include('blogAdmin.divisions.parts.divisionAddNew')
@endsection


@push('js')
@endpush
